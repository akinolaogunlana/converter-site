(function () {
  function convert(value, from, to, special) {
    if (special === 'temperature') {
      // normalize to celsius first
      let c;
      if (from === 'celsius') c = value;
      else if (from === 'fahrenheit') c = (value - 32) * (5 / 9);
      else if (from === 'kelvin') c = value - 273.15;
      if (to === 'celsius') return c;
      if (to === 'fahrenheit') return c * (9 / 5) + 32;
      if (to === 'kelvin') return c + 273.15;
    }
    return value * (from / to); // from/to are toBase factors passed in
  }

  function init(root) {
    const input = root.querySelector('[data-role="input"]');
    const output = root.querySelector('[data-role="output"]');
    const swapBtn = root.querySelector('[data-role="swap"]');
    const fromFactor = parseFloat(root.dataset.fromFactor);
    const toFactor = parseFloat(root.dataset.toFactor);
    const special = root.dataset.special || null;
    const fromUnit = root.dataset.fromUnit;
    const toUnit = root.dataset.toUnit;

    function format(n) {
      if (!isFinite(n)) return '—';
      if (Math.abs(n) >= 1e9 || (Math.abs(n) < 1e-6 && n !== 0)) return n.toExponential(4);
      return parseFloat(n.toFixed(6)).toString();
    }

    function run() {
      const v = parseFloat(input.value);
      if (isNaN(v)) { output.value = ''; return; }
      let result;
      if (special === 'temperature') {
        result = convert(v, fromUnit, toUnit, special);
      } else {
        result = convert(v, fromFactor, toFactor, null);
      }
      output.value = format(result);
    }

    input.addEventListener('input', run);
    if (swapBtn) {
      swapBtn.addEventListener('click', function () {
        window.location.href = root.dataset.swapUrl;
      });
    }
    run();
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-converter]').forEach(init);
  });
})();
