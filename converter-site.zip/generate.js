const fs = require('fs');
const path = require('path');

const SITE_NAME = 'Convertly'; // CHANGE ME before you launch
const SITE_URL = 'https://example.com'; // CHANGE ME - your real domain, no trailing slash
const OUT = path.join(__dirname, 'dist');
const units = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/units.json'), 'utf8'));

function slugify(s) { return s.replace(/_/g, '-'); }
function titleCase(s) { return s.replace(/_/g, ' '); }

function head(title, description, canonical) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<meta name="description" content="${description}">
<link rel="canonical" href="${canonical}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
</head>
<body>`;
}

function header(crumbs) {
  return `<header class="site"><div class="wrap">
  <a class="wordmark" href="/">${SITE_NAME}<span class="dot">.</span></a>
  <nav class="crumbs">${crumbs}</nav>
</div></header>`;
}

function footer() {
  return `<footer class="site"><div class="wrap">
  Free unit conversions, generated from live data. No signup, no tracking beyond what keeps the lights on.
</div></footer>`;
}

function adSlot(label) {
  return `<div class="ad-slot">[ ${label} — drop your AdSense / Carbon Ads / EthicalAds unit here ]</div>`;
}

function pageWrap(bodyHtml) {
  return `${bodyHtml}
<script src="/assets/converter.js"></script>
</body></html>`;
}

// ---------- Homepage ----------
function buildHome() {
  const cats = Object.entries(units).map(([key, cat]) => {
    const n = Object.keys(cat.units).length;
    const pairCount = n * (n - 1);
    return `<a href="/${slugify(key)}/"><div class="cat-name">${cat.label}</div><div class="cat-count">${pairCount} conversions</div></a>`;
  }).join('\n');

  const html = head(
    `${SITE_NAME} — Free unit converters`,
    `Fast, free unit conversion tools for length, weight, volume, temperature, digital storage, time, speed and area.`,
    `${SITE_URL}/`
  ) + `
${header('')}
<main class="wrap">
  <h1>Convert anything. Instantly.</h1>
  <p class="subhead">No ads blocking the number you came for, no account, no watching a spinner. Pick a category, pick your units, done.</p>
  <div class="category-grid">
  ${cats}
  </div>
  ${adSlot('homepage banner')}
</main>
${footer()}`;
  write('index.html', pageWrap(html));
}

// ---------- Category index ----------
function buildCategory(key, cat) {
  const dir = path.join(OUT, slugify(key));
  fs.mkdirSync(dir, { recursive: true });

  const rows = Object.entries(cat.units).map(([uKey, u]) =>
    `<tr><td>${u.label}</td><td>${u.symbol}</td></tr>`
  ).join('\n');

  const links = [];
  for (const fromKey of Object.keys(cat.units)) {
    for (const toKey of Object.keys(cat.units)) {
      if (fromKey === toKey) continue;
      links.push(`<a href="/${slugify(key)}/${slugify(fromKey)}-to-${slugify(toKey)}/">${cat.units[fromKey].symbol} → ${cat.units[toKey].symbol}</a>`);
    }
  }

  const html = head(
    `${cat.label} Converter — ${SITE_NAME}`,
    `Convert between every ${cat.label.toLowerCase()} unit: ${Object.values(cat.units).map(u => u.label).join(', ')}.`,
    `${SITE_URL}/${slugify(key)}/`
  ) + `
${header(`<a href="/">Home</a> / ${cat.label}`)}
<main class="wrap">
  <h1>${cat.label} converter</h1>
  <p class="subhead">Every unit, every combination, calculated instantly in your browser.</p>
  <table class="unit-table">
    <tr><th>Unit</th><th>Symbol</th></tr>
    ${rows}
  </table>
  ${adSlot('category page banner')}
  <div class="related">
    <h2>All ${cat.label.toLowerCase()} conversions</h2>
    <div class="pill-list">${links.join('\n')}</div>
  </div>
</main>
${footer()}`;
  write(path.join(slugify(key), 'index.html'), pageWrap(html));
}

// ---------- Individual conversion page ----------
function buildConversionPage(key, cat, fromKey, toKey) {
  const from = cat.units[fromKey];
  const to = cat.units[toKey];
  const dir = path.join(OUT, slugify(key), `${slugify(fromKey)}-to-${slugify(toKey)}`);
  fs.mkdirSync(dir, { recursive: true });

  const special = cat.special ? key : '';
  const fromFactor = cat.special ? '' : from.toBase;
  const toFactor = cat.special ? '' : to.toBase;
  const swapUrl = `/${slugify(key)}/${slugify(toKey)}-to-${slugify(fromKey)}/`;

  // related: same category, different pairs (sample a handful for internal linking)
  const others = Object.keys(cat.units).filter(k => k !== fromKey && k !== toKey).slice(0, 6);
  const relatedLinks = others.map(k =>
    `<a href="/${slugify(key)}/${slugify(fromKey)}-to-${slugify(k)}/">${from.symbol} → ${cat.units[k].symbol}</a>`
  ).join('\n');

  const title = `Convert ${from.label} to ${to.label} — ${SITE_NAME}`;
  const desc = `Free ${from.label.toLowerCase()} to ${to.label.toLowerCase()} converter. Enter a value and get an instant, accurate result.`;
  const canonical = `${SITE_URL}/${slugify(key)}/${slugify(fromKey)}-to-${slugify(toKey)}/`;

  const html = head(title, desc, canonical) + `
${header(`<a href="/">Home</a> / <a href="/${slugify(key)}/">${cat.label}</a> / ${from.label} to ${to.label}`)}
<main class="wrap">
  <h1>${from.label} to ${to.label}</h1>
  <p class="subhead">Type a number and see the ${to.label.toLowerCase()} equivalent update as you go.</p>

  <div class="converter" data-converter
       data-from-factor="${fromFactor}" data-to-factor="${toFactor}"
       data-from-unit="${fromKey}" data-to-unit="${toKey}"
       data-special="${special}" data-swap-url="${swapUrl}">
    <div class="field-row">
      <div class="field">
        <label for="in">${from.label} (${from.symbol})</label>
        <input id="in" data-role="input" type="number" value="1" inputmode="decimal">
      </div>
      <button class="swap-btn" data-role="swap" title="Swap units" aria-label="Swap units">⇄</button>
      <div class="field">
        <label for="out">${to.label} (${to.symbol})</label>
        <input id="out" data-role="output" type="text" readonly>
      </div>
    </div>
    ${cat.special ? '' : `<p class="factor-note">1 ${from.symbol} = ${(from.toBase / to.toBase).toPrecision(6)} ${to.symbol}</p>`}
  </div>

  ${adSlot('in-content unit')}

  <div class="related">
    <h2>More from ${from.label.toLowerCase()}</h2>
    <div class="pill-list">${relatedLinks}</div>
  </div>
</main>
${footer()}`;
  write(path.join(slugify(key), `${slugify(fromKey)}-to-${slugify(toKey)}`, 'index.html'), pageWrap(html));
}

function write(relPath, content) {
  const full = path.join(OUT, relPath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, content);
}

// ---------- Sitemap ----------
function buildSitemap(allUrls) {
  const urls = allUrls.map(u => `  <url><loc>${u}</loc></url>`).join('\n');
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
  write('sitemap.xml', xml);
}

function buildRobots() {
  write('robots.txt', `User-agent: *\nAllow: /\nSitemap: ${SITE_URL}/sitemap.xml\n`);
}

// ---------- Run ----------
function main() {
  fs.rmSync(OUT, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });
  fs.mkdirSync(path.join(OUT, 'assets'), { recursive: true });
  fs.copyFileSync(path.join(__dirname, 'assets/style.css'), path.join(OUT, 'assets/style.css'));
  fs.copyFileSync(path.join(__dirname, 'assets/converter.js'), path.join(OUT, 'assets/converter.js'));

  const allUrls = [`${SITE_URL}/`];
  buildHome();

  let pageCount = 1;
  for (const [key, cat] of Object.entries(units)) {
    buildCategory(key, cat);
    allUrls.push(`${SITE_URL}/${slugify(key)}/`);
    pageCount++;
    for (const fromKey of Object.keys(cat.units)) {
      for (const toKey of Object.keys(cat.units)) {
        if (fromKey === toKey) continue;
        buildConversionPage(key, cat, fromKey, toKey);
        allUrls.push(`${SITE_URL}/${slugify(key)}/${slugify(fromKey)}-to-${slugify(toKey)}/`);
        pageCount++;
      }
    }
  }

  buildSitemap(allUrls);
  buildRobots();

  console.log(`Generated ${pageCount} pages into /dist`);
}

main();
